class Led:
	def __init__(self):
		self.x_start = 0
		self.x_end = 0
		self.y_start = 0;
		self.y_end = 0;
		self.position = 0;