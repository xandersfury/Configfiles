# plugin.program.hyperion.configurator

This is KODI plugin, that should help every user to set up hyperion for Lightberry.

Execution of the plugin consists of several basic steps that will hellp creating hyperion config json file.

For more advanced settings, user should edit the file manually.

See [our blog post](http://raspberry-at-home.com/kodi-plugin-hyperion-configurator/) for detailed tutorial.

We hope this will be useful for many users :)

Lightberry Team

TODO:
- better error handling
